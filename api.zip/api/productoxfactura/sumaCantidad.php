<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass, $db_name);

    if(mysqli_connect_errno()){
        die('No fue posible conectarse a la base de datos' . mysqli_connect_error());
    }

$idProducto=$_GET['idProducto'];


$stmt = $conn->prepare("SELECT sum(cantidad) from productosxfactura where idProducto = '".$idProducto."';");

$stmt->execute();

$stmt->bind_result($cantidad);


$productosxfactura = array();

    while($stmt->fetch()){

        $temp = array();
        $temp['cantidad'] = $cantidad;
    
        array_push($productosxfactura, $temp);
    }


    echo json_encode($productosxfactura);


?>

