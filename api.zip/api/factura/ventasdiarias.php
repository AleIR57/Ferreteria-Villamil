<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass, $db_name);

    if(mysqli_connect_errno()){
        die('No fue posible conectarse a la base de datos' . mysqli_connect_error());
    }


$stmt2 = $conn->prepare("SET lc_time_names = 'es_ES';");

$stmt2->execute();

$stmt = $conn->prepare("SELECT v.fecha, DAYNAME(v.fecha) AS Dia,
       SUM(v.cantidadTotal) AS Total
    FROM factura v
    WHERE YEAR(v.fecha) = '2021'
    GROUP BY Dia
    ORDER BY Dia ASC;");

$stmt->execute();

$stmt->bind_result($fecha, $dia, $total);

$ventas = array();

    while($stmt->fetch()){

        $temp = array();
        $temp['fecha'] = $fecha;
        $temp['dia'] = $dia;
        $temp['total'] = $total;
    
        array_push($ventas, $temp);
    }


    echo json_encode($ventas);



?>

