<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass)
or trigger_error (mysqli_error($conn), E_USER_ERROR);
mysqli_select_db($conn, $db_name);


$id=$_POST['id'];
$cantidad=$_POST['cantidad'];

$query2 = "select * from producto where idProducto = '".$id."'";
$query_execute2 = mysqli_query($conn, $query2) or die (mysqli_error($conn));

$arr1 = array();
$cantidad2 = 0;
while ($row=mysqli_fetch_array($query_execute2)) {
    $arra = array('idProducto' => $row['idProducto'],'nombre' => $row['nombre'], 'marca' => $row['marca'], 'descripcion' => $row['descripcion'], 'precio' => $row['precio'],
        'imagen' => $row['imagen'], 'idCategoria' => $row['idCategoria'], 'cantidad' => $row['cantidad']);
    $cantidad2 = $row['cantidad'];
    array_push($arr1, $arra);
    echo json_encode(array('producto' => $arr1));
    

}


$resultado = $cantidad2-$cantidad;

$query = "update producto set cantidad = '".$resultado."' where idProducto= '".$id."'";
//$query = "insert into personas(dni, nombre, telefono, email) values ('1', 'asd', 'asd', 'asd')";
$query_execute = mysqli_query($conn, $query) or die (mysqli_error($conn));

mysqli_close($conn);

?>