<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass)
or trigger_error (mysqli_error($conn), E_USER_ERROR);
mysqli_select_db($conn, $db_name);


$idProducto=$_POST['idProducto'];
$nombre=$_POST['nombre'];
$marca=$_POST['marca'];
$descripcion=$_POST['descripcion'];
$precio=$_POST['precio'];
$imagen=$_POST['imagen'];
$idCategoria=$_POST['idCategoria'];
$cantidad=$_POST['cantidad'];



$query = "insert into producto (idProducto,nombre,marca,descripcion,precio,imagen,idCategoria,cantidad) values ('".$idProducto."','".$nombre."','".$marca."','".$descripcion."','".$precio."','".$imagen."','".$idCategoria."','".$cantidad."')";
//$query = "insert into personas(dni, nombre, telefono, email) values ('1', 'asd', 'asd', 'asd')";
$query_execute = mysqli_query($conn, $query) or die (mysqli_error($conn));


?>