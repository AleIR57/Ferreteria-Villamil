<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass, $db_name);

    if(mysqli_connect_errno()){
        die('No fue posible conectarse a la base de datos' . mysqli_connect_error());
    }




$stmt = $conn->prepare("SELECT idUsuario, nombre, correo, contrasena, telefono, direccion, identificacion, idRol FROM usuario;");

$stmt->execute();

$stmt->bind_result($idUsuario, $nombre, $correo, $contrasena, $telefono, $direccion, $identificacion, $idRol);



$usuario = array();

    while($stmt->fetch()){

        $temp = array();
        $temp['idUsuario'] = $idUsuario;
        $temp['nombre'] = $nombre;
        $temp['correo'] = $correo;
        $temp['contrasena'] = $contrasena;
        $temp['telefono'] = $telefono;
        $temp['direccion'] = $direccion;
        $temp['identificacion'] = $identificacion;
        $temp['idRol'] = $idRol;

        array_push($usuario, $temp);
    }


    echo json_encode($usuario);


?>